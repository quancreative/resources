class PortfolioController < SwfBaseController
  def index
  end

  def show
  end

end
