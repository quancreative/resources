class ContactController < SwfBaseController
  def show
  end

end
