module FrontHelper
end
