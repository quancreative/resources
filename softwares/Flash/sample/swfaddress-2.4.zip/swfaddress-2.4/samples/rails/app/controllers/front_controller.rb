class FrontController < SwfBaseController

  def index

  end

end
