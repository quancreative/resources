class AboutController < SwfBaseController

  def show

  end

end
