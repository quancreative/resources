        <script type="text/javascript">
        // <![CDATA[
            var s = new swfIN('<?php swfaddress_resource('/website.swf'); ?>', 'website', '100%', '100%');
            s.useSWFAddress();
            s.addParam('bgcolor', '#CCCCCC');
            s.addParam('menu', 'false');
            s.hideSEO("container");
            s.write();
        // ]]>
        </script>
