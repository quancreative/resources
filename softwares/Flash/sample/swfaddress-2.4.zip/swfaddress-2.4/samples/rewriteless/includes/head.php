        <script type="text/javascript" src="<?php swfaddress_optimizer('/swfaddress/swfaddress-optimizer.js?flash=8'); ?>"></script>
        <title><?php swfaddress_title('SWFAddress Website'); ?></title>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <style type="text/css">
        /*<![CDATA[*/
            html {
                height: 100%;
                overflow: hidden;
            }
            #container {
                height: 100%;
            }
            #container div {
                margin: 10px;
            }
            body {
                height: 100%;
                margin: 0;
                padding: 0;
                background: #FFFFFF;
                font: 86% Arial, "Helvetica Neue", sans-serif;
            }
        /*]]>*/
        </style>
        <script type="text/javascript" src="<?php swfaddress_resource('/swfin/swfIN.js'); ?>"></script>
        <script type="text/javascript" src="<?php swfaddress_resource('/swfaddress/swfaddress.js'); ?>"></script>
