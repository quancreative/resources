            <div id="navigation">
                <h1><a href="<?php swfaddress_link('/'); ?>">SWFAddress Website</a></h1>
                <ul>
                    <li><a href="<?php swfaddress_link('/about.php'); ?>">SWFAddress Website / About</a></li>
                    <li>
                        <a href="<?php swfaddress_link('/portfolio.php'); ?>">SWFAddress Website / Portfolio</a>
                        <ul>
                            <li><a href="<?php swfaddress_link('/portfolio.php?id=1'); ?>">SWFAddress Website / Portfolio / 1</a></li>
                            <li><a href="<?php swfaddress_link('/portfolio.php?id=2'); ?>">SWFAddress Website / Portfolio / 2</a></li>
                            <li><a href="<?php swfaddress_link('/portfolio.php?id=3'); ?>">SWFAddress Website / Portfolio / 3</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php swfaddress_link('/contact.php'); ?>">SWFAddress Website / Contact</a></li>
                </ul>
            </div>
