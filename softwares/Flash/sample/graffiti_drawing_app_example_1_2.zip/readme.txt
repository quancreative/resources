Before you can publish this project you will need to download:

1) The Graffiti Library 1.2 and place the com folder in the same directory as graffiti_demo.fla.

http://www.nocircleno.com/graffiti/source/graffiti_library_1.2.zip


2) Adobe AS3 Core Library and place it in the com folder.

http://code.google.com/p/as3corelib/

