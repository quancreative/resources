ReviewTube
----------

Author: Joe Berkovitz (http://joeberkovitz.com)


ABOUT REVIEWTUBE

ReviewTube is a Flex 2 application that allows users to create
time-based subtitles for any YouTube video, a la closed
captioning. These captions become publicly accessible, and visitors to
the site can browse the set of videos with captions. Think of it as a
"subtitle graffiti wall" for YouTube!

I wrote ReviewTube partly because I think it�s a fun and potentially
useful idea, but also as a sample application illustrating design
patterns covered in my MAX 2006 presentation on Flex Best Practices. 


CONTENTS

  html-template/
          (HTML template files for FlexBuilder)

  src/
          ReviewTube.css          top level stylesheet
          ReviewTube.mxml         main application component

          com/
             joeberkovitz/
                reviewtube/
                  controller/     Controller classes
                  events/         Event classes
                  model/          Model classes
                  services/       Service and Operation classes
                  util/           Utility classes
                  view/           View classes
                      assets/     image files for views


BUILDING and RUNNING REVIEWTUBE

The application requires a valid YouTube developer ID, which you can
obtain from YouTube (http://www.youtube.com/dev).  Rename
src/com/joeberkovitz/services/ReviewTubeComponents.mxml.template
to ReviewTubeComponents.mxml, and substitute your own developer ID
into the definition of <YouTubeMediaService>.

ReviewTube may be built either in Flex Builder or by using the Flex
2.0 SDK to run mxmlc against ReviewTube.mxml.

